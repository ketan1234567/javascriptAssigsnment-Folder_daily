//1-Remove the duplicates from array.

// const arr=[1,1,2,2,4,5,6,12];
// const unique = [...new Set(arr)];
// console.log(unique);
//************************************************************
//2-Find a second largest number from array

// const arr = [2,5,4,9,6,7,3,6,10];
// let first = -Infinity;
// let second = -Infinity;

// for(let num of arr){
// if (num > first){
//     second = first;
//     first = num;
// }else if (num > second && num !== first){
//     second = first;
// }

// }console.log(second);
//************************************************************

//3-Reverse and array without using Reverse
// const arr = [1,2,3,4,5];
// const reversed = [];
// for (let i = arr.length - 1; i >=0; i-- ){
//     reversed.push(arr[i]);
// }
// console.log(reversed);

//*********************************************************** */

//4- Move all zeroes to end

// const arr = [0,1,2,0,5,3];
// const result = arr.filter(num => num != 0);
// const zeroes = new Array(arr.length - result.length).fill(0);
// console.log([...result,...zeroes]);

// ****************************************************************

//5-Check Two Arrays are Equal

// const arr1 = [1, 2, 3];
// const arr2 = [1, 2, 4];

// const isEqual =
//   arr1.length == arr2.length && arr1.every((val, index) => val === arr2[index]);
// console.log(isEqual);

// ****************************************************************

// 6-Reverse a string without using a inbuilt function
// const str = "hello";

// let reversed = "";
// for (let i = str.length - 1; i >=0; i--) {
//     reversed += str[i];
// }
// console.log(reversed);

// ****************************************************************

//7-check palindrome string
// const str = "madam";
// const reversed = str.split('').reverse().join('');

// console.log(str === reversed);

//******************************************************************

//8- count vowels in string

// const str = "javascript";
// let count = 0;
// const vowels = "aeiou";
// for (let char of str.toLocaleLowerCase()){
//     if (vowels.includes(char)) {
//         count++;
//     }
// }
// console.log(count);

//******************************************************************

//9- Remove duplicate characters
// const str = "fgsdajfgdsaf";
// const result = [...new Set(str)].join('');
// console.log(result);

//******************************************************************
// 10-check Anagram
// const str1 = "listen";
// const str2 = "silent";

// const isAnagram =
//   str1.split("").sort().join("") === str2.split("").sort().join("");

// console.log("10-Anagram", isAnagram);

//******************************************************************

//11-Count Frequecy of characters

// const str = "PratikPratik";
// const freq = {};

// for (let char of str) {
//   freq[char] = (freq[char] || 0) + 1;
// }

// console.log("11-Count Frequecy of characters", freq);
//******************************************************************

//12. Capitalize First Letter of Each Word

// const sentence = "hello world javascript";

// const result = sentence
//   .split(" ")
//   .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
//   .join(" ");

// console.log("12. Capitalize First Letter of Each Word : ", result);
//******************************************************************

//13. Find Longest Word in Sentence

// const sentence = "I love javascript programming";

// const words = sentence.split(" ");

// let longest = "";

// for (let word of words) {
//   if (word.length > longest.length) {
//     longest = word;
//   }
// }

// console.log("Longest Word : ", longest);
//******************************************************************

// Reverse an array without using a reverse()

// const arr = [1, 2, 3, 4, 5];
// let reversed = [];
// for (let i = arr.length - 1; i >= 0; i--) {
//   reversed.push(arr[i]);
// }
// console.log(reversed);
//******************************************************************

// Move all zeroes to end
// const arr = [1, 0, 2, 0, 3, 0, 4, 0];
// const result = arr.filter((num) => num != 0);
// const zeroes = new Array(arr.length - result.length).fill(0);
// console.log([...result,...zeroes]);
//******************************************************************

// find frequency of array
// const arr = [1, 1, 2, 5, 1, 5, 2, 8, 5, 4];
// const freq = {};
// for (let item of arr) {
//   freq[item] = (freq[item] || 0) + 1;
// }
// console.log(freq);
//******************************************************************

//Find Nearest Number to Target
// const arr = [10, 2, 5, 6, 7, 8, 12, 35];
// const target = 13;
// let nearest = arr[0];
// for (let num of arr) {
//   if (Math.abs(num - target) < Math.abs(nearest - target)) {
//     nearest = num;
//   }
// }
// console.log(nearest);

//******************************************************************

// Find largest and smallest number
// const arr = [10, 12, 16, 48, 5, 66, 20];
// let max = arr[0];
// let min = arr[0];

// for (let num of arr) {
//   if (num > max) max = num;
//   if (num < min) min = num;
// }

// console.log(max);
// console.log(min);

//******************************************************************

// find duplicate elements
// const arr = [1,2,1,2,5,3,6,4];  

// const duplicates = arr.filter(
//   (item,index)=>arr.indexOf(item) !== index
// );
// console.log([...new Set(duplicates)]);


//******************************************************************
//Find first non repeated number
